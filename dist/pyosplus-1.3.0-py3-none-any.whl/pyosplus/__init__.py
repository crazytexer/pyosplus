from .pyosplus import (
    count_in_dir, ext_files, find_files_dirs, inc_name, write_dir_tree
    )
